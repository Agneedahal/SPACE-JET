[app]
title = Cosmic Defender
package.name = cosmicdefender
package.domain = org.cosmicdefender
source.dir = .
source.include_exts = py,json,wav,png,jpg,jpeg,ttf
version = 1.0
requirements = python3,pygame
orientation = landscape
fullscreen = 1
android.api = 35
android.minapi = 23
android.archs = arm64-v8a,armeabi-v7a
android.allow_backup = 0
android.permissions =
presplash.filename =
icon.filename =

[buildozer]
log_level = 2
warn_on_root = 1
