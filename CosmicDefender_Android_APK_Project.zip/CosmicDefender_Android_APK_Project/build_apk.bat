@echo off
title Cosmic Defender APK Builder
echo.
echo COSMIC DEFENDER - Android APK Builder
echo.
echo This script must be run inside WSL2 Ubuntu with Buildozer installed.
echo.
echo Run:
echo   wsl
echo   cd /mnt/c/path/to/CosmicDefender_Android_APK_Project
echo   buildozer -v android debug
echo.
echo The APK will be created in the bin folder.
pause
